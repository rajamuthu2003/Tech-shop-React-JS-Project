import "./App.css";
import Featureproducts from "./componets/Featureproducts";
import Header from "./componets/Header";
import Navbarproducts from "./componets/Navbarproducts";
import Slider from "./componets/Slider";
import Prodataroute from "./componets/Top-products/Prodataroute";
import Proroute from "./componets/Top-products/Proroute";
import { useLocation } from "react-router-dom";
import Footer from "./Footer";
import ShopNav from "./ShopNav";

function App() {
  const location = useLocation();

  const hideComponentsOnPaths = ["/product-detail", "/cart"];

  const showShopNavOnlyPaths = [
    "/shopnav",
    "/allshoppingproduct",
    "/toprated",
    "/featured",
    "/latest",
    "/pricehigh",
    "/pricelow",
  ];

  const shouldHideComponents = hideComponentsOnPaths.some((path) =>
    location.pathname.startsWith(path)
  );

  const isShopNavOrCategoryPage = showShopNavOnlyPaths.some((path) =>
    location.pathname.startsWith(path)
  );

  return (
    <>
      <Header />

      {/* Conditional Rendering for ShopNav and product components */}
      {isShopNavOrCategoryPage && (
        <>
          <ShopNav />
        </>
      )}

      {!isShopNavOrCategoryPage && (
        <>
          <Prodataroute />
          {!shouldHideComponents && <Slider />}
          {!shouldHideComponents && <Featureproducts />}
          {!shouldHideComponents && <Navbarproducts />}
          <Proroute />
        </>
      )}

      <Footer />
    </>
  );
}

export default App;

