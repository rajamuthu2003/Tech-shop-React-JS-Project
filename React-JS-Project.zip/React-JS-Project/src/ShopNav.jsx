// import Allshopping from "./Allshopping";

// import Ouradvantages from "./Ouradvantages";
// // import Shoproute from "./Shopingallproducts/Shoproute";
// import './Shopnav.css';

// function ShopNav(){
//     return <>
           
//            <div className="related-sub">
//            <h2 className="related-pro">Related Products</h2>
//            </div>
//            <div className="main-shopnav">
           
//             <div className="allshopn-side">
//             <Allshopping />
//             </div>
//             <div>
//             <Shoproute />
//             </div>
//         </div>
//            <div>
//             <Ouradvantages />
//             </div>
//            </>
// }
// export default ShopNav;


import React from "react";
import Allshopping from "./Allshopping";
import Ouradvantages from "./Ouradvantages";
// import Shoproute from "./Shopingallproducts/Shoproute"; 
import "./Shopnav.css";

function ShopNav() {
  return (
    <>
      <div className="related-sub">
        <h2 className="related-pro">All Products</h2>
      </div>
      <div className="main-shopnav">
        <div className="allshopn-side">
          <Allshopping />
        </div>
        {/* <div className="shoproute-main">
          <Shoproute /> 
        </div> */}
      </div>
      <div>
        <Ouradvantages />
      </div>
    </>
  );
}

export default ShopNav;
