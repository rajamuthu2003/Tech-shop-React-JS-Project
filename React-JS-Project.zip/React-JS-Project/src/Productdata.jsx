import jbl660nc1 from './products/jbl660nc-1.png';
import jbl660nc2 from './products/jbl660nc-2.png';
import jbl660nc3 from './products/jbl660nc-3.png';
import jbl660nc4 from './products/jbl660nc-4.png';

import boat5181 from './products/boat518-1.png'
import boat5182 from './products/boat518-2.png'
import boat5183 from './products/boat518-3.png'
import boat5184 from './products/boat518-4.png'

import boat1311 from './products/boat131-1.png'
import boat1312 from './products/boat131-2.png'
import boat1313 from './products/boat131-3.png'
import boat1314 from './products/boat131-4.png'

import boat1101 from './products/boat110-1.png'
import boat1102 from './products/boat110-2.png'
import boat1103 from './products/boat110-3.png'
import boat1104 from './products/boat110-4.png'

import boat4101 from './products/boat410-1.png'
import boat4102 from './products/boat410-2.png'
import boat4103 from './products/boat410-3.png'
import boat4104 from './products/boat410-4.png'

import jbl200bt1 from './products/jbl200bt-1.png'
import jbl200bt2 from './products/jbl200bt-2.png'
import jbl200bt3 from './products/jbl200bt-3.png'
import jbl200bt4 from './products/jbl200bt-4.png'

import sonyxb910n1 from './products/sonyxb910n-1.png'
import sonyxb910n2 from './products/sonyxb910n-2.png'
import sonyxb910n3 from './products/sonyxb910n-3.png'
import sonyxb910n4 from './products/sonyxb910n-4.png'

import jbl760nc1 from './products/jbl760nc-1.png'
import jbl760nc2 from './products/jbl760nc-1.png'
import jbl760nc3 from './products/jbl760nc-1.png'
import jbl760nc4 from './products/jbl760nc-1.png'

import boat255r1 from './products/boat255r-1.png'
import boat255r2 from './products/boat255r-2.png'
import boat255r3 from './products/boat255r-3.png'
import boat255r4 from './products/boat255r-4.png'

import jbl1001 from './products/jbl100-1.png'
import jbl1002 from './products/jbl100-2.png'
import jbl1003 from './products/jbl100-3.png'
import jbl1004 from './products/jbl100-4.png'

import sony1000xm41 from './products/sony1000xm4-1.png'
import sony1000xm42 from './products/sony1000xm4-2.png'
import sony1000xm43 from './products/sony1000xm4-3.png'
import sony1000xm44 from './products/sony1000xm4-4.png'

import boat2281 from './products/boat228-1.png'
import boat2282 from './products/boat228-2.png'
import boat2283 from './products/boat228-3.png'
import boat2284 from './products/boat228-4.png'

import jblendu1 from './products/jbl-endu-1.png'
import jblendu2 from './products/jbl-endu-2.png'
import jblendu3 from './products/jbl-endu-3.png'
import jblendu4 from './products/jbl-endu-4.png'

import boat2031 from './products/boat203-1.png'
import boat2032 from './products/boat203-2.png'
import boat2033 from './products/boat203-3.png'
import boat2034 from './products/boat203-4.png'

import sonych710n1 from './products/sonych710n-1.png'
import sonych710n2 from './products/sonych710n-2.png'
import sonych710n3 from './products/sonych710n-3.png'
import sonych710n4 from './products/sonych710n-4.png'

import jbl500bt1 from './products/jbl500bt-1.png'
import jbl500bt2 from './products/jbl500bt-2.png'
import jbl500bt3 from './products/jbl500bt-3.png'
import jbl500bt4 from './products/jbl500bt-4.png'

import boat3811 from './products/boat381-1.png'
import boat3812 from './products/boat381-2.png'
import boat3813 from './products/boat381-3.png'
import boat3814 from './products/boat381-4.png'


import sonyex14ap1 from './products/sony-ex14ap-1.png'
import sonyex14ap2 from './products/sony-ex14ap-2.png'
import sonyex14ap3 from './products/sony-ex14ap-3.png'
import sonyex14ap4 from './products/sony-ex14ap-4.png'

import sonyxb4001 from './products/sonyxb400-1.png'
import sonyxb4002 from './products/sonyxb400-2.png'
import sonyxb4003 from './products/sonyxb400-3.png'
import sonyxb4004 from './products/sonyxb400-4.png'












const productsData = [
    {
        id: 1,
        tag: "hero-product",
        tagline: "Keep the noise out, or in. You choose.",
        heroImage:  jbl660nc1,
        images: [
            jbl660nc1,
            jbl660nc2,
            jbl660nc3,
            jbl660nc4,
        ],
        brand: "JBL",
        title: "JBL Live 660NC",
        info: "Wireless Over-Ear NC Headphones",
        category: "Headphones",
        type: "Over Ear",
        connectivity: "Wireless",
        finalPrice: 9999,
        originalPrice: 14999,
        quantity: 1,
        ratings: 1234,
        rateCount: 5,
        path: "/product-details/",
    },
    {
        id: 2,
        tag: "featured-product",
        images: [
            boat5181,
            boat5182,
            boat5183,
            boat5184
        ],
        brand: "boAt",
        title: "boAt Rockerz 518",
        info: "On-Ear Wireless Headphones",
        category: "Headphones",
        type: "On Ear",
        connectivity: "Wireless",
        finalPrice: 1299,
        originalPrice: 3990,
        quantity: 1,
        ratings: 1321,
        rateCount: 5,
        path: "/product-details/",
    },
    {
        id: 3,
        tag: "hero-product",
        tagline: "Featherweight for comfort all-day.",
        heroImage: boat1313,
        images: [
            boat1311,
            boat1312,
            boat1313,
            boat1314,
        ],
        brand: "boAt",
        title: "boAt Airdopes 131",
        info: "Wireless In-Ear Earbuds",
        category: "Earbuds",
        type: "In Ear",
        connectivity: "Wireless",
        finalPrice: 1099,
        originalPrice: 2990,
        quantity: 1,
        ratings: 1244,
        rateCount: 5,
        path: "/product-details/",
    },
    {
        id: 4,
        images: [
            boat1101,
            boat1102,
            boat1103,
            boat1104,
        ],
        brand: "boAt",
        title: "boAt BassHeads 110",
        info: "In-Ear Wired Earphones",
        category: "Earphones",
        type: "In Ear",
        connectivity: "Wired",
        finalPrice: 449,
        originalPrice: 999,
        quantity: 1,
        ratings: 556,
        rateCount: 4,
        path: "/product-details/",
    },
    {
        id: 5,
        images: [
            boat4101,
            boat4102,
            boat4103,
            boat4104,
        ],
        brand: "boAt",
        title: "boAt Rockerz 410",
        info: "Bluetooth & Wired On-Ear Headphones",
        category: "Headphones",
        type: "On Ear",
        connectivity: "Bluetooth & Wired",
        finalPrice: 1599,
        originalPrice: 2990,
        quantity: 1,
        ratings: 1563,
        rateCount: 5,
        path: "/product-details/",
    },
    {
        id: 6,
        images: [
            jbl200bt1,
            jbl200bt2,
            jbl200bt3,
            jbl200bt4,
        ],
        brand: "JBL",
        title: "JBL Live 200BT",
        info: "In-Ear Wireless Neckbands",
        category: "Neckbands",
        type: "In Ear",
        connectivity: "Wireless",
        finalPrice: 3699,
        originalPrice: 5299,
        quantity: 1,
        ratings: 836,
        rateCount: 4,
        path: "/product-details/",
    },
    {
        id: 7,
        tag: "hero-product",
        tagline: "Give your favourite music a boost.",
        heroImage:sonyxb910n1,
        images: [
            sonyxb910n1,
            sonyxb910n2,
            sonyxb910n3,
            sonyxb910n4,
        ],
        brand: "Sony",
        title: "Sony WH-XB910N",
        info: "Wireless Over-Ear Headphones",
        category: "Headphones",
        type: "Over Ear",
        connectivity: "Wireless",
        finalPrice: 13489,
        originalPrice: 19990,
        quantity: 1,
        ratings: 679,
        rateCount: 4,
        path: "/product-details/",
    },
    {
        id: 8,
        tag: "featured-product",
        images: [
            jbl760nc1,
            jbl760nc2,
            jbl760nc3,
            jbl760nc4,
        ],
        brand: "JBL",
        title: "JBL Tune 760NC",
        info: "Wireless Over-Ear NC Headphones",
        category: "Headphones",
        type: "Over Ear",
        connectivity: "Wireless",
        finalPrice: 5999,
        originalPrice: 7999,
        quantity: 1,
        ratings: 755,
        rateCount: 4,
        path: "/product-details/",
    },
    {
        id: 9,
        tag: "featured-product",
        images: [
            boat255r1,
            boat255r2,
            boat255r3,
            boat255r4,
        ],
        brand: "boAt",
        title: "boAt Rockerz 255",
        info: "In-Ear Wireless Neckbands",
        category: "Neckbands",
        type: "In Ear",
        connectivity: "Wireless",
        finalPrice: 899,
        originalPrice: 2990,
        quantity: 1,
        ratings: 1464,
        rateCount: 5,
        path: "/product-details/",
    },
    {
        id: 10,
        images: [
            jbl1001,
            jbl1002,
            jbl1003,
            jbl1004,
        ],
        brand: "JBL",
        title: "JBL Wave 100",
        info: "In-Ear Truly Wireless Earbuds",
        category: "Earbuds",
        type: "In Ear",
        connectivity: "Wireless",
        finalPrice: 2999,
        originalPrice: 6999,
        quantity: 1,
        ratings: 801,
        rateCount: 4,
        path: "/product-details/",
    },
    {
        id: 11,
        images: [
            sony1000xm41,
            sony1000xm42,
            sony1000xm43,
            sony1000xm44
        ],
        brand: "Sony",
        title: "Sony WF-1000XM4",
        info: "Wireless In-Ear NC Headphones",
        category: "Earbuds",
        type: "In Ear",
        connectivity: "Wireless",
        finalPrice: 19990,
        originalPrice: 24990,
        quantity: 1,
        ratings: 382,
        rateCount: 3,
        path: "/product-details/",
    },
    {
        id: 12,
        images: [
            boat2281,
            boat2282,
            boat2283,
            boat2284,
        ],
        brand: "boAt",
        title: "boAt BassHeads 228",
        info: "In-Ear Wired Earphones",
        category: "Earphones",
        type: "In Ear",
        connectivity: "Wired",
        finalPrice: 649,
        originalPrice: 1190,
        quantity: 1,
        ratings: 1178,
        rateCount: 5,
        path: "/product-details/",
    },
    {
        id: 13,
        tag: "featured-product",
        images: [
            jblendu1,
            jblendu2,
            jblendu3,
            jblendu4,
        ],
        brand: "JBL",
        title: "JBL Endurance Run Sports",
        info: "In-Ear Wired Earphones",
        category: "Earphones",
        type: "In Ear",
        connectivity: "Wired",
        finalPrice: 999,
        originalPrice: 1599,
        quantity: 1,
        ratings: 1144,
        rateCount: 5,
        path: "/product-details/",
    },
    {
        id: 14,
        tag: "featured-product",
        images: [
            boat2031,
            boat2032,
            boat2033,
            boat2034,
        ],
        brand: "boAt",
        title: "boAt Airdopes 203",
        info: "In-Ear Truly Wireless Earbuds",
        category: "Earbuds",
        type: "In Ear",
        connectivity: "Wireless",
        finalPrice: 1074,
        originalPrice: 3999,
        quantity: 1,
        ratings: 1340,
        rateCount: 5,
        path: "/product-details/",
    },
    {
        id: 15,
        images: [
            sonych710n1,
            sonych710n2,
            sonych710n3,
            sonych710n4,
        ],
        brand: "Sony",
        title: "Sony WH-CH710N",
        info: "Wireless Over-Ear NC Headphones",
        category: "Headphones",
        type: "Over Ear",
        connectivity: "Wireless",
        finalPrice: 8520,
        originalPrice: 14990,
        quantity: 1,
        ratings: 853,
        rateCount: 4,
        path: "/product-details/",
    },
    {
        id: 16,
        images: [
            jbl500bt1,
            jbl500bt2,
            jbl500bt3,
            jbl500bt4,
        ],
        brand: "JBL",
        title: "JBL Tune 500BT",
        info: "On-Ear Wireless Headphones",
        category: "Headphones",
        type: "On Ear",
        connectivity: "Wireless",
        finalPrice: 3282,
        originalPrice: 3999,
        quantity: 1,
        ratings: 364,
        rateCount: 4,
        path: "/product-details/",
    },
    {
        id: 17,
        images: [
            boat3811,
            boat3812,
            boat3813,
            boat3814
        ],
        brand: "boAt",
        title: "boAt Airdopes 381",
        info: "In-Ear Wireless Earbuds",
        category: "Earbuds",
        type: "In Ear",
        connectivity: "Wireless",
        finalPrice: 1699,
        originalPrice: 4990,
        quantity: 1,
        ratings: 1011,
        rateCount: 5,
        path: "/product-details/",
    },
    {
        id: 18,
        images: [
            sonyex14ap1,
            sonyex14ap2,
            sonyex14ap3,
            sonyex14ap4
        ],
        brand: "Sony",
        title: "Sony MDR-EX14AP",
        info: "In-Ear Wired Earphones",
        category: "Earphones",
        type: "In Ear",
        connectivity: "Wired",
        finalPrice: 549,
        originalPrice: 1290,
        quantity: 1,
        ratings: 530,
        rateCount: 4,
        path: "/product-details/",
    },
    {
        id: 19,
        images: [
            sonyxb4001,
            sonyxb4002,
            sonyxb4003,
            sonyxb4004,
        ],
        brand: "Sony",
        title: "Sony WI-XB400",
        info: "Wireless Extra Bass In-Ear Neckbands",
        category: "Neckbands",
        type: "In Ear",
        connectivity: "Wireless",
        finalPrice: 2690,
        originalPrice: 4990,
        quantity: 1,
        ratings: 474,
        rateCount: 4,
        path: "/product-details/",
    },
];

export default productsData;