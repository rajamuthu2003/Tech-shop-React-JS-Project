import { Routes,Route, Navigate } from "react-router-dom";
import React from 'react';
import Featured from "./Featured";
import Toprated from "./Toprated";
import Latest from "./Latest";
import Pricehigh from "./Pricehigh";
import Pricelow from "./Pricelow";
import AllShoppingproduct from "./AllShoppingproducts.jsx";

function Shoproute(){
    return <>
      <Routes>
      {/* <Route path="/shopnav" element={<Navigate to="/allshoppingproduct" />} /> */}
        {/* <Route path="/allshoppingproduct" element={<AllShoppingproduct />}></Route> */}
        <Route path="/featured" element={<Featured />}></Route>
        <Route path="/toprated" element={<Toprated />}></Route>
        <Route path="/latest" element={<Latest />}></Route>
        <Route path="/pricehigh" element={<Pricehigh />}></Route>
        <Route path="/pricelow" element={<Pricelow />}></Route>
    </Routes>
           </>
}
export default Shoproute;