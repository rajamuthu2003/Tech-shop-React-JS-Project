import Featureproducts from "./componets/Featureproducts";
// import Header from "./componets/Header";
import Navbarproducts from "./componets/Navbarproducts";
import Slider from "./componets/Slider";
// import Prodataroute from "./componets/Top-products/Prodataroute";
import Proroute from "./componets/Top-products/Proroute";


function Home(){
    return <>
      {/* <Header /> */}
      {/* <Prodataroute /> */}
      {/* <Slider />
      <Featureproducts />
      <Navbarproducts />
      <Proroute /> */}
     
          </>
}
export default Home;