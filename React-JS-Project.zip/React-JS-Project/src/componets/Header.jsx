import React, { useState, useRef, useEffect, useContext } from 'react';
import './Header.css';
import { FaSearch } from "react-icons/fa";
import { AiOutlineShoppingCart } from "react-icons/ai";
import { LuUserRound } from "react-icons/lu";
import { Link, useNavigate } from 'react-router-dom';
import productsData from '../Productdata';

import { CartContext } from '../Contextpage'; 

function Header() {
    const [showSearchBar, setShowSearchBar] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [filteredProducts, setFilteredProducts] = useState([]);
    const [showUserDialog, setShowUserDialog] = useState(false);
    const [showChoiceBox, setShowChoiceBox] = useState(true);
    const [isLoginForm, setIsLoginForm] = useState(true);
    const [dialogPosition, setDialogPosition] = useState({ top: 0, left: 0 });
    const userIconRef = useRef(null);
    const navigate = useNavigate();
    
   
    const { cart } = useContext(CartContext);


    useEffect(() => {
        if (userIconRef.current && showChoiceBox) {
            const rect = userIconRef.current.getBoundingClientRect();
            setDialogPosition({ 
                top: rect.top + window.scrollY, 
                left: rect.left + window.scrollX - 310 // Align to the left of the user icon
            });
        }
    }, [showUserDialog, showChoiceBox]);

    const handleSearchIconClick = () => {
        setShowSearchBar(!showSearchBar);
        setSearchQuery('');
        setFilteredProducts([]);
    };

    const handleSearchChange = (e) => {
        const query = e.target.value.toLowerCase();
        setSearchQuery(query);

        if (query) {
            const filtered = productsData.filter(product =>
                product.title.toLowerCase().includes(query)
            );
            setFilteredProducts(filtered);
        } else {
            setFilteredProducts([]);
        }
    };

    const closeSearchOverlay = () => {
        setShowSearchBar(false);
        setSearchQuery('');
        setFilteredProducts([]);
    };

    const handleProductClick = (id) => {
        navigate(`/product-detail/${id}`);
    };

    const handleUserIconClick = () => {
        setShowUserDialog(!showUserDialog);
        setShowChoiceBox(true);
    };

    const closeUserDialog = () => {
        setShowUserDialog(false);
    };

    const selectForm = (isLogin) => {
        setIsLoginForm(isLogin);
        setShowChoiceBox(false);
    };

    return (
        <>
            <section className='main-head'>
                <section className='sub-head1'>
                    <h1><Link to="/">Tech-Shop</Link></h1>
                </section>
                <section className='sub-head2'>
                    <ul>
                        <li onClick={handleSearchIconClick} className='searchicon'><FaSearch /></li>
                        <li className='cart-icon'><Link to="/cart"><AiOutlineShoppingCart /> {cart.length > 0 && <span className='cart-count'>{cart.length}</span>} </Link></li>
                        <li
                            ref={userIconRef}
                            onClick={handleUserIconClick}
                            className='usericon'
                        >
                            <LuUserRound />
                        </li>
                    </ul>
                </section>
            </section>
            {showSearchBar && (
                <div className='search-overlay'>
                    <button className='close-btn' onClick={closeSearchOverlay}>✖</button>
                    <input
                        type='text'
                        value={searchQuery}
                        onChange={handleSearchChange}
                        placeholder='Search for products...'
                    />
                    {filteredProducts.length > 0 ? (
                        <ul>
                            {filteredProducts.map(product => (
                                <li
                                    key={product.id}
                                    onClick={() => handleProductClick(product.id)}
                                >
                                    {product.title}
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p>No results found</p>
                    )}
                </div>
            )}
            {showUserDialog && (
                <div
                    className={`user-dialog ${!showChoiceBox ? 'centered-dialog' : ''}`}
                    style={
                        showChoiceBox
                            ? {
                                  top: `${dialogPosition.top}px`,
                                  left: `${dialogPosition.left}px`,
                              }
                            : {}
                    }
                >
                    <div className='dialog-content'>
                        <button className='close-btn' onClick={closeUserDialog}>✖</button>
                        {showChoiceBox ? (
                            <div className='choice-box'>
                               <h2>Hello!</h2>
                               <p>Access account and manage orders</p>
                               <p className='formsnames'><span onClick={() => selectForm(true)}>Login</span> /
                                 <span onClick={() => selectForm(false)}> Signup</span></p> 
                                 <hr />
                            <p>Please Login</p>
                             
                               
                             
                            </div>
                        ) : (
                            <>
                                {isLoginForm ? (
                                    <>
                                       <div className='loginform-main'>
                                       <h2>Login</h2>
                                        <p className='cursor'>New to Tech-Shop ? <span onClick={() => setIsLoginForm(false)}>Create an account</span></p>
                                        <form>
                                            <input type='email' placeholder='Email' required /><br></br>
                                            <input type='password' placeholder='Password' required /><br></br>
                                            <button type='submit' className='login-but'>Login</button>
                                        </form>
                                         <div className='sub-login'>
                                            <div>
                                               <p>
                                               <hr />
                                               </p>
                                               <button className='face-but'>Facebook</button>
                                            </div>
                                            <div>
                                            <p> or login with</p>
                                            <button className='google-but'>Google</button>
                                            </div>
                                            <div>
                                            <p><hr /></p>
                                            <button className='twitter-but'>Twitter</button>
                                            </div>
                                         </div>

                                       </div>
                                       
                                    </>
                                ) : (
                                    <>
                                         <div className='loginform-main'>
                                       <h2>Signup</h2>
                                       <p className='cursor'>Already have an account? <span onClick={() => setIsLoginForm(true)}>Login</span></p>
                                        <form>
                                            <input type='text' placeholder='UserName' required /><br></br>

                                            <input type='email' placeholder='Email' required /><br></br>
                                            <input type='password' placeholder='Password' required /><br></br>
                                            <input type='password' placeholder='Confirm Password' required /><br></br>
                                            <button type='submit' className='login-but'>Login</button>
                                        </form>
                                         <div className='sub-login'>
                                            <div>
                                               <p>
                                               <hr />
                                               </p>
                                               <button className='face-but'>Facebook</button>
                                            </div>
                                            <div>
                                            <p className='orloginwith'> or login with</p>
                                            <button className='google-but'>Google</button>
                                            </div>
                                            <div>
                                            <p><hr /></p>
                                            <button className='twitter-but'>Twitter</button>
                                            </div>
                                         </div>

                                       </div>

                                    </>
                                )}
                            </>
                        )}
                    </div>
                </div>
            )}
        </>
    );
}

export default Header;



