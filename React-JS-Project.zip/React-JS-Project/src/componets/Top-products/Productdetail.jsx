import React, { useState } from "react";
import { useParams } from "react-router-dom";
import productsData from "../../Productdata"; // Import the product data
import "./Productdetail.css"; // Import a CSS file for styling
import { TiTick } from "react-icons/ti";

import  { useContext } from "react";
import { CartContext } from "../../Contextpage";
import userprofile from '../../products/user.jpg';
import Ouradvantages from "../../Ouradvantages";



function Productdetail() {
  const [activeSection, setActiveSection] = useState("specifications");

  const { addToCart } = useContext(CartContext);

  const { id } = useParams(); // Get the product ID from the URL
  const product = productsData.find((p) => p.id === parseInt(id)); // Find the product by ID

  const [mainImage, setMainImage] = useState(product?.images[0]); // Set the initial main image

  if (!product) {
    return <h2>Product not found!</h2>;
  }

  const handleThumbnailClick = (image) => {
    setMainImage(image); // Update the main image when a thumbnail is clicked
  };

  // Calculate the savings
  const savings = product.originalPrice - product.finalPrice;
  const discountPercentage = Math.round((savings / product.originalPrice) * 100);

  return (
    <>
    <div className="product-detail">
      {/* Section 1: Side Thumbnails */}
      <div className="product-thumbnails">
        <div className="thumbnail-container">
          {product.images.map((image, index) => (
            <img
              key={index}
              src={image}
              alt={`Thumbnail ${index + 1}`}
              className={`thumbnail ${image === mainImage ? "active" : ""}`} // Highlight the selected thumbnail
              onClick={() => handleThumbnailClick(image)} // Set the clicked thumbnail as the main image
            />
          ))}
        </div>
      </div>

      {/* Section 2: Main Image */}
      <div className="product-main-image">
        <img src={mainImage} alt={product.title} className="main-image" />
      </div>

      {/* Section 3: Product Details */}
      <div className="product-info">
        <h1 className="product-title">{product.title}</h1>
        <p className="product-description">{product.info}</p>
        <p className="product-ratings">
          <span className="stars">★★★★☆</span> | {product.ratings} Ratings
        </p>
        <hr />
        <p className="product-price">
          <span className="final-price">₹{product.finalPrice}</span>{" "}
          <span className="original-price">₹{product.originalPrice}</span>{" "}
          {/* <span className="discount">({discountPercentage}% off)</span> */}
        </p>
        <p className="saving">
          <strong>You save:</strong> ₹{savings} ({discountPercentage}%)
        </p>
        <p className="taxes">(Inclusive of all taxes)</p>
        <p className="product-stock">
        <TiTick /> In Stock
        </p>
        <hr />
        <p className="offers">Offers and Discounts</p>
        <div className="offer-buttons">
          <button className="offer-button">No Cost EMI on Credit Card</button>
          <button className="offer-button">Pay Later & Avail Cashback</button>
        </div>
        <p><hr /></p>
        <button className="addtocart"  onClick={() => addToCart(product)} >Add to cart</button>
      </div>


     
    </div>



<section className="specific">
      <div className="buttons-container">
        <button
          className={`specific-but ${activeSection === "specifications" ? "active-red" : ""}`}
          onClick={() => setActiveSection("specifications")}
        >
          Specifications
        </button>
        <button
          className={`specific-but ${activeSection === "overview" ? "active-red" : ""}`}
          onClick={() => setActiveSection("overview")}
        >
          Overview
        </button>
        <button
          className={`specific-but ${activeSection === "reviews" ? "active-red" : ""}`}
          onClick={() => setActiveSection("reviews")}
        >
          Review
        </button>
      </div>

      {activeSection === "specifications" && (
        <div className="specif-main">
          <p>
            Brand <span className="specific-span">{product.brand}</span>
          </p>
          <p>
            Model <span className="specific-span">{product.title}</span>
          </p>
          <p>
            Generic Name <span className="specific-span">{product.brand}</span>
          </p>
          <p>
            Headphone Type <span className="specific-span">{product.type}</span>
          </p>
          <p>
            Connectivity <span className="specific-span">{product.connectivity}</span>
          </p>
          <p>
            Microphone <span className="specific-span">Yes</span>
          </p>
        </div>
      )}

      {activeSection === "overview" && (
        <div className="overview-section">
          <h3>
            The <span className="title-span">{product.title}</span> {product.type} Truly {product.connectivity} {product.category} Provides
            with fabulous sound quality
          </h3>
          <ul>
            <li>Sound Tuned to Perfection</li>
            <li>Comfortable to Wear</li>
            <li>Long Hours Playback Time</li>
          </ul>
          <p>
            Buy the {product.title} {product.type} Truly {product.type} {product.connectivity}{" "}
            {product.category} which offers you with fabulous music experience by providing you with
            awesome sound quality that you can never move on from. Enjoy perfect flexibility and mobility
            with amazing musical quality with these Earbuds giving you a truly awesome audio experience.
            It blends with exceptional sound quality and a range of smart features for an unrivalled
            listening experience.
          </p>
        </div>
      )}

      {activeSection === "reviews" && (
        <div className="review-section">
          <div className="review-sub">
          <img src={userprofile} alt="user" className="userprofile" />
            <h2>Atharva Kumar</h2>
           <p className="para1">★★★★★ <span className="para-span">| 4 Aug 2022</span></p>
            <p className="para2">Sound is awesome and as I expected, love it.</p>
          </div>
          <div className="review-sub">
          <img src={userprofile} alt="user" className="userprofile" />
            <h2>Ritika Sen</h2>
            <p className="para1">★★★★★ <span className="para-span"> | 15 July 2022</span></p>
            <p className="para2">Very good and awesome product.</p>
          </div>
          <div className="review-sub">
          <img src={userprofile} alt="user" className="userprofile" />
            <h2>Bhavesh Joshi</h2>
            <p className="para1">★★★★ <span className="para-span"> | 10 June 2022</span></p>
            <p className="para2">Super amazing product !!!.</p>
          </div>
          <div className="review-sub">
          <img src={userprofile} alt="user" className="userprofile" />
            <h2>Anandi Gupta</h2>
            <p className="para1">★★★★★<span className="para-span"> | 6 May 2022</span></p>
            <p className="para2">Great NC, sound is a bit flat.</p>
          </div>
          <div className="review-sub">
          <img src={userprofile} alt="user" className="userprofile" />
            <h2>Arif Khan</h2>
            <p className="para1"> ★★★★★ <span className="para-span"> | 27 April 2022</span></p>
            <p className="para2">Very good but still has flaws!</p>
          </div>
        </div>
      )}
    </section>
    <Ouradvantages />
    </>


  );
}

export default Productdetail;
