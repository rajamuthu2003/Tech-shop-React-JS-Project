

// import React, { useContext } from "react";
// import { CartContext } from "../../Contextpage"; // Adjust the path
// import { BsCartX } from "react-icons/bs";
// import { RiDeleteBin6Line } from "react-icons/ri";
// import "./Cart.css";

// function Cart() {
//     const { cart, removeFromCart } = useContext(CartContext);

//     // Calculate total original price, total discount, and total price
//     const totalOriginalPrice = cart.reduce((total, item) => total + item.originalPrice * item.quantity, 0);
//     const totalDiscount = cart.reduce((total, item) => total + (item.originalPrice - item.finalPrice) * item.quantity, 0);
//     const totalPrice = cart.reduce((total, item) => total + item.finalPrice * item.quantity, 0);

//     return (
//         <div className="cart-main">
//             {cart.length === 0 ? (
//                 <div className="cart-main">
//                     <p className="cart-icon"><BsCartX /></p>
//                     <h1 className="cart-head">Your Cart is Empty</h1>
//                     <button className="cart-but">Start Shopping</button>
//                 </div>
//             ) : (
                
//                 <section className="main-cart-item">
//                 <section className="cart-items">
//                     {cart.map((item) => (
//                         <div className="cart-item" key={item.id}>
//                             <div>
//                                 <img src={item.images[0]} alt={item.title} className="cart-image" />
//                             </div>
//                             <div>
//                                 <h3>{item.title} - {item.info}</h3>
//                                 <p className="final-price"> ₹{item.finalPrice} <strike className="original-price"> ₹{item.originalPrice}</strike></p>
//                                 <p><button>+</button> {item.quantity} <button>-</button> </p>
//                                 <hr className="harizon" />
//                             </div>
//                             <div>
//                                 <button
//                                     className="remove-btn"
//                                     onClick={() => removeFromCart(item.id)}
//                                 >
//                                     <RiDeleteBin6Line />
//                                 </button>
//                             </div>
//                         </div>
//                     ))}

//                   </section>
//             <section>
//             <div className="order-summary">
//            <h2>Order Summary ({cart.length} items)</h2>
//             <div>
                
//                 <p className="totalorinal-price">Original price <span className="totalorinal"> ₹{totalOriginalPrice}</span></p>
//                 <p className="totalorinal-price">Discount<span className="totaldiscount"> -₹{totalDiscount}</span></p>
//                 <p className="totalorinal-price">Delivery:<span className="totaldiscount2"> Free</span></p>
//                 <hr />
//                 <p className="totalprice">Total price <span className="totalprice2">₹{totalPrice}</span></p>
//                 <button className="check-but">Checkout</button>
//             </div>
//            </div>
//             </section>
//                 </section>
//             )}
          
//         </div>
//     );
// }

// export default Cart;

import React, { useContext } from "react";
import { CartContext } from "../../Contextpage"; // Adjust the path
import { BsCartX } from "react-icons/bs";
import { RiDeleteBin6Line } from "react-icons/ri";
import "./Cart.css";
import { Link } from "react-router-dom";
import Ouradvantages from "../../Ouradvantages";

function Cart() {
    const { cart, removeFromCart, updateQuantity } = useContext(CartContext);

    // Calculate total original price, total discount, and total price
    const totalOriginalPrice = cart.reduce((total, item) => total + item.originalPrice * item.quantity, 0);
    const totalDiscount = cart.reduce((total, item) => total + (item.originalPrice - item.finalPrice) * item.quantity, 0);
    const totalPrice = cart.reduce((total, item) => total + item.finalPrice * item.quantity, 0);

    return (
        <>
        <div className="cart-main">
            {cart.length === 0 ? (
                <div className="cart-main">
                    <p className="cart-icon-subpage"><BsCartX /></p>
                    <h1 className="cart-head">Your Cart is Empty</h1>
                    <button className="cart-but"><Link to='/shopnav'>Start Shopping</Link> </button>
                </div>
            ) : (
                <section className="main-cart-item">
                    <section className="cart-items">
                        {cart.map((item) => (
                            <div className="cart-item" key={item.id}>
                                <div>
                                    <img src={item.images[0]} alt={item.title} className="cart-image" />
                                </div>
                                <div>
                                    <h3>{item.title} - {item.info}</h3>
                                    <p className="final-price">
                                        ₹{item.finalPrice} <strike className="original-price"> ₹{item.originalPrice}</strike>
                                    </p>
                                    <p className="quantity-increse-decrese">
                                       <button className="increse-but" onClick={() => updateQuantity(item.id, "decrease")}>-</button>
                                        
                                        <button className="middle-quantty">{item.quantity}</button>
                                        <button className="increse-but" onClick={() => updateQuantity(item.id, "increase")}>+</button> 
                                    </p>
                                    <hr className="harizon" />
                                </div>
                                <div>
                                    <button
                                        className="remove-btn"
                                        onClick={() => removeFromCart(item.id)}
                                    >
                                        <RiDeleteBin6Line />
                                    </button>
                                </div>
                            </div>
                        ))}
                    </section>

                    <section>
                        <div className="order-summary">
                            <h2>Order Summary ({cart.length} items)</h2>
                            <div>
                                <p className="totaloriginal-price">Original price <span className="totaloriginal"> ₹{totalOriginalPrice}</span></p>
                                <p className="totaldiscount-price">Discount <span className="totaldiscount"> -₹{totalDiscount}</span></p>
                                <p className="totaldelivery-price">Delivery: <span className="totaldiscount2"> Free</span></p>
                                <hr />
                                <p className="totalprice">Total price <span className="totalprice2">₹{totalPrice}</span></p>
                                <button className="check-but">Checkout</button>
                            </div>
                        </div>
                    </section>
                </section>
            )}
        </div>

        <Ouradvantages />
        </>
    );
}

export default Cart;

