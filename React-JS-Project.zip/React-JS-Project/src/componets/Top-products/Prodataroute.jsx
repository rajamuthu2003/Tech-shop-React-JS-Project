import { Routes,Route } from "react-router-dom";
import React from "react";
import Productdetail from "./Productdetail";
import Home from "../../Home";
import Cart from "./Cart";
import ShopNav from "../../ShopNav";


function Prodataroute(){
   return <>
  <Routes>
  <Route path="/" element={<Home />} />

  <Route path="/product-detail/:id" element={<Productdetail />} />
  <Route path="/cart" element={<Cart />} />
  <Route path='/shopnav' element={<ShopNav />} />
 
 
  </Routes>

    </>
}
export default Prodataroute;