import { Routes,Route } from "react-router-dom";
import Allproducts from "./Allproducts";
import Earbuds from "./Earbuds";
import Earphones from "./Earphones";
import Headphones from "./Headphones";
import Neckbands from "./Neckbands";
// import Productdetail from "./Productdetail";
// import Productdetail from "../../Productdetail";


function Proroute(){
    return <>
    <Routes>
      <Route path="/" element={<Allproducts />} />
      <Route path="/earbuds" element={<Earbuds />} />
      <Route path="/earphones" element={<Earphones />} />
      <Route path="/headphones" element={<Headphones />} />
      <Route path="/neckbands" element={<Neckbands />} />
      {/* <Route path="/product-detail/:id" element={<Productdetail />} /> */}
      
   </Routes>
      
           </>
}
export default Proroute;