import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'; // Import useNavigate from react-router-dom
import boat from '../products/boat131-3.png';
import jbl from '../products/jbl660nc-1.png';
import sony from '../products/sonyXb910n-1.png';
import './Slider.css';

function Slider() {
    const [currentSlide, setCurrentSlide] = useState(0);
    const [isAnimating, setIsAnimating] = useState(true);
    const navigate = useNavigate(); // Initialize useNavigate hook

    const slides = [
        {
            id: 3,
            title: 'boAt Airdopes 131',
            subtitle: 'Featherweight for comfort all-day.',
            price: '₹1099',
            originalPrice: '₹2990',
            image: boat,
        },
        {
            id: 1,
            title: 'JBL Live 660NC',
            subtitle: `Keep The Noise Out, Or In. You Choose.`,
            price: '₹9,999',
            originalPrice: '₹14,999',
            image: jbl,
        },
        {
            id: 7,
            title: 'Sony WH-XB910N',
            subtitle: 'Give Your Favourite Music A Boost.',
            price: '₹13,489',
            originalPrice: '₹19,990',
            image: sony,
        },
    ];

    // Add duplicate first slide at the end for seamless transition
    const extendedSlides = [...slides, slides[0]];

    useEffect(() => {
        const interval = setInterval(() => {
            setIsAnimating(true);
            setCurrentSlide((prev) => prev + 1);
        }, 2000);

        return () => clearInterval(interval);
    }, []);

    useEffect(() => {
        // Reset position when reaching the duplicate slide
        if (currentSlide === slides.length) {
            setTimeout(() => {
                setIsAnimating(false);
                setCurrentSlide(0); // Reset to the first slide instantly
            }, 500); // Match the CSS transition duration
        }
    }, [currentSlide, slides.length]);

    const handleShopNowClick = (id) => {
        // Navigate to the product detail page based on the slide's id
        navigate(`/product-detail/${id}`);
    };

    return (
        <div>
            <section className="slider-container">
                <div
                    className="slides-wrapper"
                    style={{
                        transform: `translateX(-${currentSlide * 100}%)`,
                        transition: isAnimating ? 'transform 0.5s ease-in-out' : 'none',
                    }}
                >
                    {extendedSlides.map((slide, index) => (
                        <div className="slide" key={index}>
                            <section className="sub-slider1">
                                <h3>{slide.title}</h3>
                                <h1>{slide.subtitle}</h1>
                                <p className="actual-price">
                                    {slide.price}{' '}
                                    <strike className="original-price">{slide.originalPrice}</strike>
                                </p>
                                <button 
                                    className="shop-but"
                                    onClick={() => handleShopNowClick(slide.id)} // Handle the click event
                                >
                                    Shop Now
                                </button>
                            </section>
                            <section className="sub-slider2">
                                <img src={slide.image} alt={slide.title} />
                            </section>
                        </div>
                    ))}
                </div>
                <div className="dots-container">
                    {slides.map((_, index) => (
                        <span
                            key={index}
                            className={`dot ${currentSlide % slides.length === index ? 'active' : ''}`}
                            onClick={() => {
                                setCurrentSlide(index);
                                setIsAnimating(true);
                            }}
                        ></span>
                    ))}
                </div>
            </section>
        </div>
    );
}

export default Slider;
