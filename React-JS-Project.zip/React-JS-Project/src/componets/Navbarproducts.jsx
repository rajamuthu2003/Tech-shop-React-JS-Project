import { Link } from "react-router-dom";
import { useState } from "react"; 
import './Navbarpro.css';

function Navbarproducts() {
    const [active, setActive] = useState(null); 

   
    const handleClick = (index) => {
        setActive(index);
    };

    return (
    <div>
       <h1 className="top-products">Top Products</h1>

         <section className="main-navbar">
            <section className="sub-navpro">
                <h1 
                    onClick={() => handleClick(0)} 
                    className={active === 0 ? 'active' : ''}
                >
                    <Link to="/">All</Link>
                </h1>
            </section>

            <section>
                <h1 
                    onClick={() => handleClick(1)} 
                    className={active === 1 ? 'active' : ''}
                >
                    <Link to="/headphones">Headphones</Link>
                </h1>
            </section>

            <section>
                <h1 
                    onClick={() => handleClick(2)} 
                    className={active === 2 ? 'active' : ''}
                >
                    <Link to="/earbuds">Earbuds</Link>
                </h1>
            </section>

            <section>
                <h1 
                    onClick={() => handleClick(3)} 
                    className={active === 3 ? 'active' : ''}
                >
                    <Link to="/earphones">Earphones</Link>
                </h1>
            </section>

            <section>
                <h1 
                    onClick={() => handleClick(4)} 
                    className={active === 4 ? 'active' : ''}
                >
                    <Link to="/neckbands">Neckbands</Link>
                </h1>
            </section>
        </section>
    </div>
       
    );
}

export default Navbarproducts;
