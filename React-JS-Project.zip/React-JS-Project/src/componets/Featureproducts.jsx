
// import React, { useEffect, useState } from "react";
// import { useNavigate } from "react-router-dom"; 
// import jbl1 from "../products/jbl760nc-1.png";
// import boat1 from "../products/boat203-1.png";
// import boat2 from "../products/boat255r-1.png";
// import jbl2 from "../products/jbl-endu-1.png";
// import boat3 from "../products/boat518-1.png";
// import "./Feature.css";

// function Featureproducts() {
//   const [products, setProducts] = useState([
//     { id: 1, name: "JBL Tune 760NC", price: "₹13,489", strike: "₹13,489", image: jbl1 },
//     { id: 2, name: "boAt Airdopes 203", price: "₹1,074", strike: "₹3,999", image: boat1 },
//     { id: 3, name: "boAt Rockkerz 255", price: "₹899", strike: "₹2,990", image: boat2 },
//     { id: 4, name: "JBL Endurance Run Sports", price: "₹999", strike: "₹1,599", image: jbl2 },
//     { id: 5, name: "boAt Rockkerz 518", price: "₹13,489", strike: "₹13,489", image: boat3 },
//   ]);
//   const [currentIndex, setCurrentIndex] = useState(2); // Start with the middle product

//   useEffect(() => {
//     const interval = setInterval(() => {
//       setProducts((prevProducts) => {
//         const [first, ...rest] = prevProducts;
//         return [...rest, first];
//       });
//       setCurrentIndex((prevIndex) => (prevIndex + 1) % products.length); // Update the active dot
//     }, 2000);

//     return () => clearInterval(interval);
//   }, [products.length]);

//   const handleImageClick = (id) => {
//     // Navigate to the product detail page based on the product id
//     navigate(`/product-detail/${id}`);
//   };

//   return (
//     <>
//       <h2 className="mainfeature">Feature Products</h2>
//       <section className="feature-pro">
//         {products.map((product, index) => {
//           let className = "product";
//           if (index === 2) className += " middle"; // Middle product
//           else if (index === 1 || index === 3) className += " adjacent"; // Adjacent products

//           return (
//             <div key={product.id} className={className}>
//               <h3>{product.name}</h3>
//               <img src={product.image} alt={product.name}  onClick={() => handleImageClick(product.id)} />
//               <p>
//                 {product.price} <strike className="striker">{product.strike}</strike>
//               </p>
//             </div>
//           );
//         })}
//       </section>
//       <div className="dots-container">
//         {products.map((_, index) => (
//           <span
//             key={index}
//             className={`dot ${index === currentIndex ? "active" : ""}`}
//           ></span>
//         ))}
//       </div>
//     </>
//   );
// }

// export default Featureproducts;


import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate from react-router-dom
import jbl1 from "../products/jbl760nc-1.png";
import boat1 from "../products/boat203-1.png";
import boat2 from "../products/boat255r-1.png";
import jbl2 from "../products/jbl-endu-1.png";
import boat3 from "../products/boat518-1.png";
import "./Feature.css";

function Featureproducts() {
  const [products, setProducts] = useState([
    { id: 8, name: "JBL Tune 760NC", price: "₹13,489", strike: "₹13,489", image: jbl1 },
    { id: 14, name: "boAt Airdopes 203", price: "₹1,074", strike: "₹3,999", image: boat1 },
    { id: 9, name: "boAt Rockkerz 255", price: "₹899", strike: "₹2,990", image: boat2 },
    { id: 13, name: "JBL Endurance Run Sports", price: "₹999", strike: "₹1,599", image: jbl2 },
    { id: 2, name: "boAt Rockkerz 518", price: "₹13,489", strike: "₹13,489", image: boat3 },
  ]);
  const [currentIndex, setCurrentIndex] = useState(2); // Start with the middle product
  const navigate = useNavigate(); // Initialize useNavigate hook

  useEffect(() => {
    const interval = setInterval(() => {
      setProducts((prevProducts) => {
        const [first, ...rest] = prevProducts;
        return [...rest, first];
      });
      setCurrentIndex((prevIndex) => (prevIndex + 1) % products.length); // Update the active dot
    }, 2000);

    return () => clearInterval(interval);
  }, [products.length]);

  const handleImageClick = (id) => {
    // Navigate to the product detail page based on the product id
    navigate(`/product-detail/${id}`);
  };

  return (
    <>
      <h2 className="mainfeature">Feature Products</h2>
      <section className="feature-pro">
        {products.map((product, index) => {
          let className = "product";
          if (index === 2) className += " middle"; // Middle product
          else if (index === 1 || index === 3) className += " adjacent"; // Adjacent products

          return (
            <div key={product.id} className={className}>
              <h3>{product.name}</h3>
              {/* Make the image clickable */}
              <img
                src={product.image}
                alt={product.name}
                onClick={() => handleImageClick(product.id)} 
                style={{ cursor: 'pointer' }} 
              />
              <p>
                {product.price} <strike className="striker">{product.strike}</strike>
              </p>
            </div>
          );
        })}
      </section>
      <div className="dots-container">
        {products.map((_, index) => (
          <span
            key={index}
            className={`dot ${index === currentIndex ? "active" : ""}`}
          ></span>
        ))}
      </div>
    </>
  );
}

export default Featureproducts;
