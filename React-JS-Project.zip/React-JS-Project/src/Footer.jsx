import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Footer.css';
import { FaFacebookF, FaTwitter, FaInstagram, FaLinkedinIn, FaCreativeCommonsSa, FaChevronUp } from 'react-icons/fa';

function Footer() {
  const [scrollTopVisible, setScrollTopVisible] = useState(false);

  // Function to scroll to the top of the page
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  // Detect scroll position to show/hide the scroll-to-top icon
  const handleScroll = () => {
    if (window.scrollY > 300) {
      setScrollTopVisible(true);
    } else {
      setScrollTopVisible(false);
    }
  };

  // Use useEffect to attach the scroll event listener
  useEffect(() => {
    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <>
      <section className='footer'>
        <section className='main-footer'>
          <div>
            <h1 className='anchor'>
              <Link to="/">Tech-Shop</Link>
            </h1>
            <p>Subscribe to our Email alerts to receive early<br /> discount offers, and new products info.</p>
            <input type="text" placeholder='Email Address*' className='footer-inp' /><br />
            <button className='foot-but'>Subscribe</button>
          </div>
          <div>
            <h1>Help</h1>
            <p>FAQs</p>
            <p>Track Order</p>
            <p>Cancel Order</p>
            <p>Return Order</p>
            <p>Warranty Info</p>
          </div>
          <div>
            <h1>Policies</h1>
            <p>Return Policy</p>
            <p>Security</p>
            <p>Sitemap</p>
            <p>Privacy Policy</p>
            <p>Terms & Conditions</p>
          </div>
          <div>
            <h1>Company</h1>
            <p>About Us</p>
            <p>Contact Us</p>
            <p>Service Centres</p>
            <p>Careers</p>
            <p>Affiliates</p>
          </div>
        </section>
        <hr />
        <section className='sub-footer2'>
          <div>
            <h1 className='foot-head2'>2024 | All Rights Reserved.Built by|RAJAMUTHU M <FaCreativeCommonsSa />.</h1>
          </div>
          <div className='icon-foot'>
            <span className='footer-icons'><FaFacebookF /></span>
            <span className='footer-icons'><FaTwitter /></span>
            <span className='footer-icons'><FaInstagram /></span>
            <span className='footer-icons'><FaLinkedinIn /></span>
            {/* Conditionally render the scroll-to-top icon */}
            {scrollTopVisible && (
              <span className='footer-icons2' onClick={scrollToTop}><FaChevronUp /></span>
            )}
          </div>
        </section>
      </section>
    </>
  );
}

export default Footer;
