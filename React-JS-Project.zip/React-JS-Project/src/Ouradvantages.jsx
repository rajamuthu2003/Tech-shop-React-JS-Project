import { FaTruck } from "react-icons/fa";
import { FaShieldAlt } from "react-icons/fa";
import { FaTags } from "react-icons/fa";
import { FaCreditCard } from "react-icons/fa6";
import './Ouradvan.css';

function Ouradvantages(){
    return <>
   <section className="main-our">
   <h1 className="our-head">Our Advantages</h1>
        <div className="main-advan">
            <div className="sub-advan">
             <div>
             <p className="our-icon"><FaTruck /></p>
             </div>
             <div>
             <h3 >Express delivery</h3>
             <p>Ships in 24 Hours</p>
             </div>
            </div>
            <div className="sub-advan">
               <div>
               <p className="our-icon"><FaShieldAlt /></p>
               </div>
                <div>
                <h3>Brand Warranty</h3>
                <p>100% Original Products</p>
                </div>
            </div>
            <div className="sub-advan">
                <div>
                <p className="our-icon"><FaTags /></p>
                </div>
               <div>
               <h3>Exciting Deals</h3>
               <p>On all prepaid orders</p>
               </div>
            </div>
            <div className="sub-advan">
                <div>
                <p className="our-icon"><FaCreditCard /></p>
                </div>
                <div>
                <h3>Source Payments</h3>
                <p>SSL/ Source Certificate</p>
                </div>
            </div>
        </div>
   </section>
           </>
}
export default Ouradvantages;